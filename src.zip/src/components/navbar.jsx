import { useState, useEffect, memo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { FaBars, FaTimes } from "react-icons/fa";
import logo from "../photo/photo_optimized.jpg";

const navLinks = [
  { label: "Home", href: "#hero", route: "/" },
  { label: "About", href: "#about", route: "/" },
  { label: "Projects", href: "#projects", route: "/projects" },
  { label: "Services", href: "#services", route: "/services" },
  { label: "Contact", href: "#contact", route: "/contact" },
];

function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");
  const location = useLocation();
  const navigate = useNavigate();

  // 1. Zero-cost passive scroll listener with rAF throttle & state-boundary checking
  useEffect(() => {
    let ticking = false;
    let lastScrolled = false;

    const onScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const isPast = window.scrollY > 30;
          if (isPast !== lastScrolled) {
            lastScrolled = isPast;
            setScrolled(isPast);
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // 2. High-performance IntersectionObserver for section scrollspy (ZERO layout thrashing)
  useEffect(() => {
    if (location.pathname !== "/") return;

    const sections = ["hero", "about", "projects", "services", "contact"];
    const elements = sections
      .map((id) => document.getElementById(id))
      .filter(Boolean);

    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        // Find visible section with highest intersection ratio or top crossing
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        }
      },
      {
        rootMargin: "-20% 0px -65% 0px",
        threshold: [0, 0.2]
      }
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [location.pathname]);

  // Close mobile menu on resize to desktop (passive)
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) setOpen(false);
    };
    window.addEventListener("resize", handleResize, { passive: true });
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleNavClick = (e, item) => {
    e.preventDefault();
    setOpen(false);

    if (location.pathname === "/") {
      const targetId = item.href.replace("#", "");
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        targetEl.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      navigate("/");
      setTimeout(() => {
        const targetId = item.href.replace("#", "");
        const targetEl = document.getElementById(targetId);
        if (targetEl) {
          targetEl.scrollIntoView({ behavior: "smooth" });
        }
      }, 100);
    }
  };

  return (
    <>
      <header className={`nv-header ${scrolled ? "nv-scrolled" : ""}`}>
        <nav className="nv-bar" aria-label="Main Navigation">
          <Link
            to="/"
            className="nv-logo"
            onClick={(e) => handleNavClick(e, { href: "#hero" })}
          >
            <div className="nv-logo-wrap">
              <img
                src={logo}
                alt="Qusai Anwer"
                className="nv-logo-img"
                width="40"
                height="40"
                loading="lazy"
                decoding="async"
              />
              <span className="nv-status-dot" title="Available for opportunities" />
            </div>
            <div className="nv-logo-text">
              <span className="nv-logo-name">Qusai Anwer</span>
              <span className="nv-logo-sub">Software Engineer</span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <ul className="nv-links nv-desktop-links">
            {navLinks.map((item) => {
              const isActive =
                location.pathname === "/"
                  ? activeSection === item.href.replace("#", "")
                  : location.pathname === item.route;

              return (
                <li key={item.label}>
                  <a
                    href={item.href}
                    onClick={(e) => handleNavClick(e, item)}
                    className={`nv-link ${isActive ? "active" : ""}`}
                  >
                    {item.label}
                  </a>
                </li>
              );
            })}
          </ul>

          <div className="nv-actions">
            <a
              href="#contact"
              onClick={(e) => handleNavClick(e, { href: "#contact" })}
              className="nv-cta-btn"
            >
              Let's Talk
            </a>

            <button
              className="nv-toggle"
              onClick={() => setOpen(!open)}
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
            >
              {open ? <FaTimes /> : <FaBars />}
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile Drawer Backdrop & Menu */}
      <div
        className={`nv-backdrop ${open ? "nv-backdrop-active" : ""}`}
        onClick={() => setOpen(false)}
        aria-hidden="true"
      />

      <div className={`nv-mobile-drawer ${open ? "nv-drawer-open" : ""}`}>
        <div className="nv-drawer-head">
          <div className="nv-logo-wrap">
            <img
              src={logo}
              alt="Qusai Anwer"
              className="nv-logo-img"
              width="40"
              height="40"
              loading="lazy"
              decoding="async"
            />
          </div>
          <div>
            <div className="nv-logo-name">Qusai Anwer</div>
            <div className="nv-logo-sub">Software Engineer • WISE</div>
          </div>
        </div>

        <ul className="nv-drawer-links">
          {navLinks.map((item) => (
            <li key={item.label}>
              <a
                href={item.href}
                onClick={(e) => handleNavClick(e, item)}
                className="nv-drawer-link"
              >
                {item.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="nv-drawer-footer">
          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, { href: "#contact" })}
            className="nv-drawer-cta"
          >
            Get In Touch
          </a>
        </div>
      </div>
    </>
  );
}

export default memo(Navbar);
